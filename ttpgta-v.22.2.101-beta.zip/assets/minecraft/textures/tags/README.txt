Шрифт — картинки для чата (Private Use Area)

Каждый PNG = один символ. В чате: скопировать символ или Alt+NumPad (код).

=== ICONS (E000-E01D) ===
E000 compass      E001 dialog       E002 dialogue     E003 donate
E004 earth         E005 education    E006 error_mark   E007 explore
E008 exp_icon      E009 fider        E00A heart_full   E00B heart_half
E00C icon_cancel   E00D icon_confirm E00E information  E00F job
E010 job2          E011 job3         E012 lock         E013 logo
E014 members       E015 microphone   E016 money_icon   E017 podarok
E018 quit          E019 star         E01A tab-frame    E01B unlocked_button
E01C base/black    E01D base/blank

=== MISC — плашки (E01E-E030) ===
E01E bankir   E01F business  E020 cases    E021 doctor
E022 doyar    E023 ekzamen   E024 farmer   E025 fisher
E026 grandhouse E027 gruzchik E028 licenser E029 miner
E02A mudak    E02B onehouse  E02C parustower E02D premiertower
E02E prodavec E02F quests    E030 rabotnik

=== PERMS — плашки групп (E031-E047) ===
E031 build    E032 curator  E033 dev     E034 don1
E035 don2     E036 don3     E037 don4    E038 don5
E039 don6     E03A glbuilder E03B gldev   E03C help
E03D junior   E03E magnat   E03F media   E040 mod
E041 norp     E042 sp       E043 srhelper E044 staff
E045 stmod    E046 sup      E047 tester

=== RATING (E048-E04A) ===
E048 common    E049 legendary   E04A rare

Коды Alt+NumPad: 57344 + hex (E000=0, E001=1... E04A=74)
